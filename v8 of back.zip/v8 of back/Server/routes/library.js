const router = require("express").Router();
const conn = require("../db/dbconnection");
const authorized = require("../middleware/authorize");
const admin = require("../middleware/admin");
const { body, validationResult } = require("express-validator");
const upload = require("../middleware/uploadimages");
const { query } = require("express");
const util = require("util");
const fs = require("fs");
// Admin  [Create,UPDATE,DELETE]
router.post(
  "",
  admin,
  upload.single("pdfFileUrl"),
  body("auther"),
  body("bookName"),
  body("bookField"),
  body("description"),
  body("publicationDate"),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      const query = util.promisify(conn.query).bind(conn);
      const checkBookName = await query("select * from book where name = ?", [
        req.body.bookName,
      ]);
      if (checkBookName.length > 0) {
        res.status(400).json({
          errors: [
            {
              msg: "This Book Already exist",
            },
          ],
        });
      } else {
        if (!req.file) {
          return res.status(400).json({
            errors: [
              {
                msg: "Book PDF is required",
              },
            ],
          });
        } else {
          const book = {
            name: req.body.bookName,
            description: req.body.description,
            auther: req.body.auther,
            field: req.body.bookField,
            publicationDate: req.body.publicationDate,
            pdfFileUrl: req.file.filename,
          };
          const query = util.promisify(conn.query).bind(conn);
          await query("insert into book set ? ", book);
          res.status(200).json({
            msg: "Book created SuccessFULLy",
          });
        }
      }
    } catch (err) {
      console.log(err);
      res.json(500).json(err);
    }
  }
);

router.put(
  "/:name",
  admin,
  upload.single("pdfFileUrl"),
  body("auther"),
  body("bookName"),
  body("bookField"),
  body("description"),
  body("publicationDate"),
  async (req, res) => {
    try {
      const query = util.promisify(conn.query).bind(conn);
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      const book = await query("select * from book where name = ?", [
        req.params.name,
      ]);
      if (!book[0]) {
        res.status(404).json({
          msg: "Not Found",
        });
      } else {
        const bookObj = {
          auther: req.body.auther,
          name: req.body.bookName,
          field: req.body.bookField,
          description: req.body.description,
          publicationDate: req.body.publicationDate,
        };
        if(req.file){
          bookObj.pdfFileUrl = req.file.filename;
          fs.unlinkSync("./upload/"+book[0].pdfFileUrl)
        }
        await query("update book set ? where name = ?", [
          bookObj,
          book[0].name,
        ]);
        res.status(200).json({
          msg: "Updated successfully",
        });
      }
    } catch (err) {
      console.log(err);
      res.json(500).json(err);
    }
  }
);

router.delete("/:name", admin, async (req, res) => {
  try {
    const query = util.promisify(conn.query).bind(conn);
    const library = await query("select * from book where name = ?", [
      req.params.name,
    ]);
    if (!library[0]) {
      res.status(404).json({
        msg: "Not Found",
      });
    }
    await query("delete from book where name = ?", [library[0].name]);
    res.status(200).json({
      msg: "DELETED successfully",
    });
  } catch (err) {
    console.log(err);
    res.json(500).json(err);
  }
});

// User [get,review]
//List
router.get("", async (req, res) => {
  const query = util.promisify(conn.query).bind(conn);
  const books = await query("select * from book");
  books.map((book) => {
    book.pdfFileUrl = "http://" + req.hostname + ":4000/" + book.pdfFileUrl;
  });
  res.status(200).json(books);
});
// show
router.get("/:name", async (req, res) => {
  const query = util.promisify(conn.query).bind(conn);
  const book = await query("select * from book where name = ?", [
    req.params.name,
  ]);
  if (!book[0]) {
    res.status(404).json({ msg: "This Book is Not Found" });
  }
  book.pdfFileUrl = "http://" + req.hostname + ":4000/" + book.pdfFileUrl;
  res.status(200).json(book);
});
module.exports = router;
