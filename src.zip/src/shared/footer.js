import React from "react";
import '../style/footer.css'
const Footer = () => {
    return(
        <div className="footer">
           <h4>Copyright &copy; all reserved</h4>
        </div>
    )
}
export default Footer