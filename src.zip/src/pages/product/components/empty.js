import React from "react";
const Empty = () => {
    return(
        <div>
            <h1 style={{color: "rgb(176, 101, 101)",background:'lightGray',padding: "5px 20px"}}>
               There is no Books
            </h1>
        </div>
    )
}
export default Empty;