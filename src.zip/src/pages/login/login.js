import React, {useState } from "react";
import { createSearchParams, useNavigate } from "react-router-dom";
import "./login.css";
import Axios from "axios";
import { Link } from "react-router-dom";
const Login = () => {
  const [email,setEmail] = useState('');
  const [password,setPass] = useState('');
  const navigate = useNavigate();
  const navigateData = (e) =>{
    e.preventDefault();
    Axios.post("http://localhost:4000/Auth/login",{
      email : email,
      password : password,
    }).then((res) => {
      navigate({
        pathname:'/account',
        search : createSearchParams({
          Email : email,
        }).toString(),
      })
    }).catch((err) => {
        document.getElementById("shortc").innerHTML="You have entered a wrong email or password";
        document.getElementById("shortc").style.display = "block";
        document.getElementById("shortc").style.color = "red";
      })
  };
  return (
    <>
    <h3 style={{display : "None" ,   marginLeft: "420px" ,marginBottom: "-80px", marginTop: "80px"}} id = "shortc"></h3>
    <div style={{marginTop : "100px"}} className="container" id="container">
      <div className="form-container log-in-container">
        <form action="#" className="login-form" onSubmit={navigateData}>
          <span>
          <h1 className="login">Login</h1>
          <div className="anouther-account">or use your account</div>
          </span>
          <input
            type="email"
            placeholder="Email"
            className="text-field"
            required
            onChange={(event) => setEmail(event.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            className="pass-field"
            required
             onChange={(event) => setPass(event.target.value)}
          />
          <Link to = "/reg" ><p style={{color : "blue",marginLeft :"10px"}}>Make an Account From here..?</p> </Link>
          <button className="login-button">Log In</button>
        </form>
      </div>
    </div>
    </>
  );
};
export default Login;