export const Data = [
  {
    id: 1,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 2,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 3,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 4,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 5,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 6,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 7,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
  {
    id: 8,
    name: "Hebta",
    description:
      "It has survived not only five centuries remaining essentially unchanged.",
    auther: "Dr.Ahmed Tawfek",
    field: "Romantec",
    publicationDate: "29/2/2012",
  },
];
