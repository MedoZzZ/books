import React from "react";
import "../style/header.css";
import image from "../assets/images/logo.png"
import { Link ,useNavigate} from "react-router-dom";
import {removeAuthUser} from "../helper/storage";

const Header = () => {
  const navigate = useNavigate();
  const logout = () =>{
    removeAuthUser();
    navigate("/");
  }
  return (
    <div>
      <header className="header">
        <div className="logo">
          <img src ={image} alt ="logo" className="logo-img"/>
        </div>
        <nav className="nav">
          <ul>
            <li>
                <h3>
                   <Link to={'/home'}>Home </Link>
                </h3>
            </li>
            <li>
                <h3>
                   <Link to={'/about'}>About </Link>
                </h3>
            </li>
            <li>
                <h3>
                  <Link to={'/about'}>Contact Us </Link>
                </h3>
            </li>
            <li>
                <h3>
                 <a href = "" onClick={logout}>LogOut</a>
                 </h3>
            </li>
          </ul>
        </nav>
      </header>
    </div>
  );
};
export default Header;