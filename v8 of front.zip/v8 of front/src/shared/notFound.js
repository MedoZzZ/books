import React from "react";
const NotFound = () =>{
    return(
        <div>
            <h1 style={{color: "rgb(176, 101, 101)",background:'lightGray',padding: "5px 20px",textAlign : 'center',margin:"40px 600px"}}>
                404 Error Not Found
            </h1>
        </div>
    );
}
export default NotFound;