import React from "react";
import { createBrowserRouter}from "react-router-dom";
import ProductList from "./pages/product/productList";
import Login from "./pages/login/login";
import About from "./pages/about/about";
import Contact from "./pages/contact/contact";
import NotFound from './shared/notFound'
import App from "./App";
import Admin from "./pages/admin/adminControll/admin";
import Reader from "./pages/reader/reader";
import ProductChapterList from "./pages/product/productChaptersList";
import UpdateBook from "./pages/admin/showAvailableBooks/components/updateBook/updateBook";
import AddBook from "./pages/admin/showAvailableBooks/components/addBook/addBook";
import ShowRequests from "./pages/admin/showRequests/showRequests";
import ShowHistory from "./pages/admin/showHistory/showHistory";
import Registration from "./pages/registration/registration";
import ManageBooks from "./pages/admin/showAvailableBooks/manageBooks";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Login />,
  },
  {
    path: "/reg",
    element: <Registration />,
  },
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/",
        element: <Login />,
      },
      {
        path: "/home",
        element: <ProductList />,
      },
      {
        path: "/about",
        element: <About />,
      },
      {
        path: "/showRequests",
        element: <ShowRequests />,
      },
      {
        path: "/contact",
        element: <Contact />,
      },
      {
        path: "/manageBooks",
        children: [
        {
         path : "",
         element : <ManageBooks />
        },
        {
          path: "addBook",
          element: <AddBook />,
        },
        {
          path: ":name",
          element: <UpdateBook />,
        },
        ]
      },
      {
        path: "/showHistory",
        element: <ShowHistory />,
      },
      {
        path: "/showChapters",
        element: <ProductChapterList />,
      },
      {
        path: "/admin",
        element: <Admin />,
      },
      {
        path: "/reader",
        element: <Reader />,
      },
      {
        path: "*",
        element: <NotFound />,
      },
    ],
  },
]);