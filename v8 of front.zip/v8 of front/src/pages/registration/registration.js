import React, {useState } from "react";
import "./registration.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {Alert} from "react-bootstrap"
import Spinner from "react-bootstrap/Spinner";
import { setAuthUser } from "../../helper/storage";
const Registration = () => {
  const [reg, setReg] = useState({
    email: "",
    password: "",
    phone : "",
    loading: false,
    err: [],
  });
  const navigate = useNavigate();
  const Register = (e) => {
    e.preventDefault();
    setReg({ ...reg, loading: true, err: [] });
    axios
      .post("http://localhost:4000/Auth/register", {
        email: reg.email,
        password: reg.password,
        phone : reg.phone,
      })
      .then((resp) => {
        setReg({ ...reg, loading: false, err: [] });
        navigate("/")
      })
      .catch((errors) => {
        setReg({
          ...reg,
          loading: false,
          err: errors.response.data.errors,
        });
      });
  };

  return (
    <div style={{marginTop : "100px"}} className="container" id="container">
      <div className="form-container log-in-container">
        <form action="#" className="login-form" onSubmit={Register}>
          <h1 className="login"  style={{marginTop : "20px"}}>Registration</h1>
          <span className="anouther-account">make your account from here</span>
          <br></br>
          {reg.err.map((error, index) => (
            <Alert key={index} variant="danger" className="px-2 py-2 w-100 p-3">
              {error.msg}
            </Alert>
          ))}
          <input  style={{marginTop : "10px"}} type="email" placeholder="Email" className="text-field" value={reg.email} required onChange={(event) => setReg({ ...reg, email: event.target.value })} />
          <input type="password" placeholder="Password" className="pass-field" value={reg.password} required onChange={(event) => setReg({ ...reg, password: event.target.value })} />
          <input type="phone" placeholder="Phone" className="phone-field" value={reg.phone} required onChange={(event) => setReg({ ...reg, phone: event.target.value })} />
          <button className="login-button">Registration</button>
          {reg.loading == true && (
            <div style={{display : "flex"}}>
            <Spinner animation="border" size="sm" />
            <Spinner animation="grow" size="sm" />
            <Spinner animation="border" />
            <Spinner animation="grow" />
          </div>
          )}
        </form>
      </div>
    </div>
  );
};
export default Registration;