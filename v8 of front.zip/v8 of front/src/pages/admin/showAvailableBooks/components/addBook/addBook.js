import React, { useRef, useState } from "react";
import "./addBook.css";
import axios from "axios";
import { getAuthUser } from "../../../../../helper/storage";
import { Alert } from "react-bootstrap";
import Spinner from "react-bootstrap/Spinner";
import { useNavigate } from "react-router-dom";
const AddBook = () => {
  const auth = getAuthUser();
  const [book, setBook] = useState({
    auther: "",
    bookName: "",
    publicationDate: "",
    bookField: "",
    description: "",
    err: [],
    loading: false,
    successMessage: null,
  });
  const navigate = useNavigate();
  const pdfFileUrl = useRef(null);
  const Add = (e) => {
    e.preventDefault();
    setBook({ ...book, loading: true ,err : []});
    const formData = new FormData();
    formData.append("auther", book.auther);
    formData.append("bookName", book.bookName);
    formData.append("bookField", book.bookField);
    formData.append("description", book.description);
    formData.append("publicationDate", book.publicationDate);
    if (pdfFileUrl.current.files && pdfFileUrl.current.files[0]) {
      formData.append("pdfFileUrl", pdfFileUrl.current.files[0]);
    }
    axios
      .post("http://localhost:4000/library", formData, {
        headers: {
          token: auth.token,
          "Content-Type": "multipart/form-data",
        },
      })
      .then((res) => {
        setBook({
          auther: "",
          bookName: "",
          publicationDate: "",
          bookField: "",
          description: "",
          err:[],
          loading: false,
          successMessage: "movie Created Successfully",
        });
        pdfFileUrl.current.value = null;
        navigate(-1)
      })
      .catch((errors) => {
        setBook({
          ...book,
          loading: false,
          successMessage: null,
          err: errors.response.data.errors,
        });
      });
  };
  return (
    <div className="containerContact4">
      <div className="right-side4">
        <div className="topic-text4">
          <h1>Add Book</h1>
        </div>
        <br></br>
        {book.err.map((error, index) => (
            <Alert key={index} variant="danger" className="px-2 py-2 w-100 p-3">
              {error.msg}
            </Alert>
          ))}
        {book.successMessage && (
          <Alert variant="success" className="px-2 py-2 w-100 p-3">
            {book.successMessage}
          </Alert>
        )}
        <form action="#" onSubmit={Add}>
          <div className="input-box4">
            <input
              value={book.auther}
              type="text"
              placeholder="Enter Auther Name"
              required
              onChange={(event) =>
                setBook({ ...book, auther: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Name"
              required
              value={book.bookName}
              onChange={(event) =>
                setBook({ ...book, bookName: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Publication Date"
              required
              value={book.publicationDate}
              onChange={(event) =>
                setBook({ ...book, publicationDate: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Field"
              required
              value={book.bookField}
              onChange={(event) =>
                setBook({ ...book, bookField: event.target.value })
              }
            />
          </div>
          <br></br>
          <textarea
            style={{ marginLeft: "50px", marginTop: "9px" }}
            id="w3review"
            name="w3review"
            rows="4"
            cols="50"
            placeholder="Enter Book Description"
            required
            value={book.description}
            onChange={(event) =>
              setBook({ ...book, description: event.target.value })
            }
          />
          <br></br>
          <br></br>
          <div className="file">
            <label htmlFor="myfile">Select a Your Book file :</label>
            <input
              type="file"
              id="myfile"
              name="myfile"
              ref={pdfFileUrl}
            />
          </div>
          <br></br>
          <div className="button4">
            <button className="updateBook">Add</button>
          </div>
          {book.loading == true && (
            <div style={{display : "flex"}}>
            <Spinner animation="border" size="sm" />
            <Spinner animation="grow" size="sm" />
            <Spinner animation="border" />
            <Spinner animation="grow" />
          </div>
          )}
        </form>
      </div>
    </div>
  );
};
export default AddBook;
