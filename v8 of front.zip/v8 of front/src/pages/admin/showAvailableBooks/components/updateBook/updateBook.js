import React, { useEffect, useRef, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import "./updateBook.css";
import axios from "axios";
import { getAuthUser } from "../../../../../helper/storage";
import { Alert } from "react-bootstrap";
import Spinner from "react-bootstrap/Spinner";
import { useNavigate } from "react-router-dom";
const UpdateBook = () => {
  let { name } = useParams();
  const auth = getAuthUser();
  const pdfFileUrl = useRef(null);
  const navigate = useNavigate();
  const [book, setBook] = useState({
    auther: "",
    bookName: "",
    publicationDate: "",
    bookField: "",
    description: "",
    err: "",
    loading: false,
    reload : false,
  });
  const Update = (e) => {
    e.preventDefault();
    setBook({ ...book, loading: true, err: [] });
    const formData = new FormData();
    formData.append("auther", book.auther);
    formData.append("bookName", book.bookName);
    formData.append("bookField", book.bookField);
    formData.append("description", book.description);
    formData.append("publicationDate", book.publicationDate);
    if (pdfFileUrl.current.files && pdfFileUrl.current.files[0]) {
      formData.append("pdfFileUrl", pdfFileUrl.current.files[0]);
    }
    axios
      .put("http://localhost:4000/library/" + name, formData, {
        headers: {
          token: auth.token,
          "Content-Type": "multipart/form-data",
        },
      })
      .then((res) => {
        setBook({
          ...book,
          loading : false,
          err : "",
        })
        navigate(-1);
      })
      .catch((errors) => {
        setBook({
          ...book,
          loading: false,
          err: "There is a Something Went Wrong",
        });
      });
  };
  useEffect(() =>{
    axios
      .get("http://localhost:4000/library/"+name)
      .then((res) => {
        setBook({
          ...book,
          auther : res.data[0].name,
          bookName : res.data[0].name,
          publicationDate : res.data[0].publicationDate,
          bookField : res.data[0].field,
          description : res.data[0].description,
        });
      })
      .catch((errors) => {
        setBook({
          ...book,
          loading: false,
          err: "There is a something Went Wrong"
        });
      });
  },[book.reload])
  return (
    <div className="containerContact4">
      <div className="right-side4">
        <div className="topic-text4">
          <h1>Update Book</h1>
        </div>
        {book.err && (
          <Alert variant="danger" className="px-2 py-2 w-100 p-3">
            {book.err}
          </Alert>
        )}
        <form action="#" onSubmit={Update}>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Auther Name"
              required
              value={book.auther}
              onChange={(event) =>
                setBook({ ...book, auther: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Name"
              required
              value={book.bookName}
              onChange={(event) =>
                setBook({ ...book, bookName: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Publication Date"
              required
              value={book.publicationDate}
              onChange={(event) =>
                setBook({ ...book, publicationDate: event.target.value })
              }
            />
          </div>
          <div className="input-box4">
            <input
              type="text"
              placeholder="Enter Book Field"
              required
              value={book.bookField}
              onChange={(event) =>
                setBook({ ...book, bookField: event.target.value })
              }
            />
          </div>
          <textarea
          style={{marginLeft :"50px"}}
            id="w3review"
            name="w3review"
            rows="4"
            cols="50"
            placeholder="Enter Book Description"
            required
            value={book.description}
            onChange={(event) =>
              setBook({ ...book, description: event.target.value })
            }
          />
          <div className="file">
            <label htmlFor="myfile">Select a Your Book file :</label>
            <input
              type="file"
              id="myfile"
              name="myfile"
              ref={pdfFileUrl}
            />
          </div>
          <br></br>
          <br></br>
          <div className="button4">
            <button className="updateBook">Update</button>
            {book.loading == true && (
              <div style={{ display: "flex" }}>
                <Spinner animation="border" size="sm" />
                <Spinner animation="grow" size="sm" />
                <Spinner animation="border" />
                <Spinner animation="grow" />
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
export default UpdateBook;
