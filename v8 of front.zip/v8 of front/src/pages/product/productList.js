import React from "react";
import "./style/productList.css";
import { getAuthUser } from "../../helper/storage";
import Admin from "../admin/adminControll/admin"
import Reader from "../reader/reader"
const ProductList = () => {
  const data = getAuthUser();
  if(data.role == 1){
    return <Admin />
  }
  <Reader /> 
};
export default ProductList;