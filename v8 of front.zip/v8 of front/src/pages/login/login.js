import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";
import axios from "axios";
import { Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import { setAuthUser } from "../../helper/storage";
const Login = () => {
  const [login, setLogin] = useState({
    email: "",
    password: "",
    loading: false,
    err: [],
  });
  const navigate = useNavigate();
  const log = (e) => {
    e.preventDefault();
    setLogin({ ...login, loading: true, err: [] });
    axios
      .post("http://localhost:4000/Auth/login", {
        email: login.email,
        password: login.password,
      })
      .then((resp) => {
        setLogin({ ...login, loading: false, err: [] });
        setAuthUser(resp.data);
        if (resp.data.role == 1) {
          navigate("/admin");
        } else {
          navigate("/reader");
        }
      })
      .catch((errors) => {
        setLogin({
          ...login,
          loading: false,
          err: errors.response.data.errors,
        });
      });
  };

  return (
    <div style={{ marginTop: "100px" }} className="container" id="container">
      <div className="form-container log-in-container">
        <form action="#" className="login-form" onSubmit={log}>
          <span>
            <h1 className="login">Login</h1>
            <div className="anouther-account">or use your account</div>
          </span>
          {login.err.map((error, index) => (
            <Alert key={index} variant="danger" className="px-2 py-2 w-100 p-3">
              {error.msg}
            </Alert>
          ))}
          <input
            style={{ marginTop: "10px" }}
            type="email"
            placeholder="Email"
            className="text-field"
            value={login.email}
            required
            onChange={(event) =>
              setLogin({ ...login, email: event.target.value })
            }
          />
          <input
            type="password"
            placeholder="Password"
            className="pass-field"
            value={login.password}
            required
            onChange={(event) =>
              setLogin({ ...login, password: event.target.value })
            }
          />
          <Link to="/reg">
            <p style={{ color: "blue", marginLeft: "10px" }}>
              Make an Account From here..?
            </p>{" "}
          </Link>
          <button className="login-button" disabled={login.loading == true}>
            Log In
          </button>
          {login.loading == true && (
            <div style={{display : "flex"}}>
            <Spinner animation="border" size="sm" />
            <Spinner animation="grow" size="sm" />
            <Spinner animation="border" />
            <Spinner animation="grow" />
          </div>
          )}
          
        </form>
      </div>
    </div>
  );
};
export default Login;
